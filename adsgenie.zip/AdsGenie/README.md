# AdsGenie — Instance Management Update

This build keeps the existing campaign, forum-topic, permissions, Logs, pacing, and View Message functionality and adds administrator-side instance management.

## CLI: Edit instance

Run:

```text
python run.py
```

Choose:

```text
12. Edit instance / token / Chat ID / validity
```

Available actions:

1. Change bot token — validates the new BotFather token with Telegram **before** saving it. If the controller is running, it is stopped so it cannot keep using the old token.
2. Change customer Chat ID — updates the customer allowed to operate that instance.
3. Change instance name.
4. Assign / renew validity.
5. Disable instance.
6. Enable instance.
7. Show current data.

## Validity plans

Built-in plans:

- 7 days
- 30 days
- 45 days
- 60 days
- 90 days
- 180 days
- 365 days
- Custom 1–3650 days

When assigning validity, choose whether to set it from now or extend the existing expiration.

Customer access is checked against the **current database record** on every controller request. Disabled and expired customers are rejected. `/validity` shows active/expired status, remaining days/hours, and the expiration timestamp.

## Bot token errors

A bad token can no longer be saved through the CLI. Controller startup also catches malformed BotFather tokens and prints a clean repair instruction instead of a Python traceback.

## Safety

Account replacement remains CLI/instance-only. No controller command exposes account replacement.


## AdsGenie campaign behavior

- `/start` starts **Groups + Forums together**. There is no target-selection prompt.
- The campaign reads the already-synced authorized destinations and runs one combined queue.
- A Logs-channel Bot API rate limit is isolated from delivery; it is recorded locally and does not stop the forwarding loop.
- A Telegram MTProto `FloodWait` is treated as a rate-limit event, not a fatal controller crash. AdsGenie waits the server-requested time and then continues the queue.
- Delivery logs include target, category, forum topic, source, message ID, progress, flood-wait recovery, batch cooldown, and View Message when Telegram provides a link.
- Admins can use `/start` or `/profile` on a controller to change the linked MTProto account's name, username, bio, and profile photo.

## Lightweight multi-instance operation

The default configured instance ceiling is **40**. The controller keeps destination filtering out of the runtime path and avoids an idle Telethon connection per account; MTProto connections are opened only for delivery/profile operations. SQLite is configured with WAL and a busy timeout for concurrent controller processes.

This is an engineering target, not a guarantee that every VPS can run 40 accounts: actual capacity depends on RAM, CPU, Telegram traffic, destination count, and VPS limits. For a small VPS, start with 20 and scale upward while watching RAM/CPU. PostgreSQL is preferable when the installation becomes heavily concurrent.


## Persistent destination filter

Use CLI option `4. Sync already-joined chats (no auto-join)` to inspect chats the account already belongs to, then option `14. Filter destinations + update persistent blacklist`. The filter checks only existing destinations; it does not auto-join chats or send test messages. Only use destinations where the account is permitted and the group/channel owners have authorized the posting. Definitive no-post-permission destinations and Telegram Stars paid-message destinations are disabled and saved per instance under `runtime/blacklist/instance_XX.json`. Future sync/campaign runs skip those saved entries. Temporary/network errors are not blacklisted. No Telegram Stars are spent.

## Fresh install

This archive intentionally contains no database, sessions, runtime logs, active blacklist entries, or real credentials. Blacklist files are created automatically only when a destination is definitively ineligible. Copy `.env.example` to `.env` and enter your own settings. The default empty database is `data/adsgenie.db`.
