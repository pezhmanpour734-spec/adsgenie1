import asyncio, getpass, os
from datetime import datetime, timezone, timedelta
from sqlalchemy import select
from app.db import Session, Instance, Account, Campaign, init_db
from app.config import settings

VALIDITY_PLANS = {
    "1": 7,
    "2": 30,
    "3": 45,
    "4": 60,
    "5": 90,
    "6": 180,
    "7": 365,
}


def _parse_chat_id(raw: str) -> int:
    value = int(raw.strip())
    if value == 0:
        raise ValueError("Chat ID cannot be 0")
    return value


async def _validate_bot_token(token: str):
    """Validate a BotFather token against Telegram before saving it."""
    token = token.strip()
    if not token or ":" not in token:
        raise ValueError("Bot token format is invalid")
    from aiogram import Bot
    bot = Bot(token)
    try:
        me = await bot.get_me()
        return me
    except Exception as exc:
        raise ValueError(f"Telegram rejected the bot token: {type(exc).__name__}") from exc
    finally:
        await bot.session.close()


async def _choose_validity(current_until=None):
    print("\nValidity plans:")
    print("1. 7 days")
    print("2. 30 days")
    print("3. 45 days")
    print("4. 60 days")
    print("5. 90 days")
    print("6. 180 days")
    print("7. 365 days")
    print("8. Custom days")
    choice = input("Choose plan [2]: ").strip() or "2"
    if choice in VALIDITY_PLANS:
        days = VALIDITY_PLANS[choice]
    elif choice == "8":
        days = int(input("Number of days: ").strip())
        if days < 1 or days > 3650:
            raise ValueError("Validity must be between 1 and 3650 days")
    else:
        raise ValueError("Invalid validity plan")

    mode = input("Set from now or extend existing? [S/e]: ").strip().lower() or "s"
    now = datetime.now(timezone.utc)
    if mode.startswith("e") and current_until:
        base = current_until
        if base.tzinfo is None:
            base = base.replace(tzinfo=timezone.utc)
        until = max(now, base) + timedelta(days=days)
        action = f"extended by {days} days"
    else:
        until = now + timedelta(days=days)
        action = f"set to {days} days from now"
    return until, days, action


async def create_instance():
    async with Session() as s:
        count=(await s.execute(select(Instance))).scalars().all()
        if len(count)>=settings.max_instances:
            print("Maximum instance limit reached."); return
        iid=max([x.id for x in count], default=0)+1

    name=input(f"Instance name [AdsBot-{iid:02d}]: ").strip() or f"AdsBot-{iid:02d}"
    token=getpass.getpass("BotFather token (hidden): ").strip()
    try:
        me = await _validate_bot_token(token)
        print(f"✅ Bot verified: @{me.username or me.first_name}")
    except Exception as exc:
        print(f"❌ Bot token rejected: {exc}")
        return

    try:
        chat=_parse_chat_id(input("Customer Chat ID: "))
    except ValueError as exc:
        print(f"❌ {exc}")
        return

    try:
        until, days, action = await _choose_validity()
    except (ValueError, EOFError) as exc:
        print(f"❌ {exc}")
        return

    async with Session() as s:
        inst=Instance(id=iid,name=name,bot_token=token,customer_chat_id=chat,validity_until=until)
        acc=Account(instance_id=iid,session_path=f"{settings.session_dir}/instance_{iid}.session")
        s.add_all([inst,acc]); await s.commit()
    print(f"Created instance #{iid}: {name}")
    print(f"Validity: {days} days | expires {until.astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')}")


async def list_instances():
    async with Session() as s:
        rows=(await s.execute(select(Instance).order_by(Instance.id))).scalars().all()
        now=datetime.now(timezone.utc)
        for x in rows:
            until=x.validity_until
            if until and until.tzinfo is None: until=until.replace(tzinfo=timezone.utc)
            if until:
                remaining=max(0, int((until-now).total_seconds()))
                validity=f"{remaining//86400}d {(remaining%86400)//3600}h"
                if remaining == 0: validity="EXPIRED"
            else:
                validity="NOT SET"
            print(f"#{x.id:02d} {x.name} | {x.state} | customer={x.customer_chat_id} | validity={validity}")


async def edit_instance():
    try:
        iid=int(input("Instance ID: ").strip())
    except ValueError:
        print("Invalid instance ID."); return

    async with Session() as s:
        inst=await s.get(Instance, iid)
    if not inst:
        print(f"Instance #{iid} not found."); return

    print(f"\n========== EDIT INSTANCE #{iid:02d} ==========")
    print("1. Change bot token")
    print("2. Change customer Chat ID")
    print("3. Change instance name")
    print("4. Assign / renew validity")
    print("5. Disable instance")
    print("6. Enable instance")
    print("7. Show current data")
    choice=input("Select: ").strip()

    if choice == "1":
        token=getpass.getpass("New BotFather token (hidden): ").strip()
        try:
            me=await _validate_bot_token(token)
        except Exception as exc:
            print(f"❌ Token NOT changed: {exc}"); return
        # Stop the running controller so it cannot continue using the old token.
        try:
            from app.process_manager import stop
            stop(iid)
        except Exception:
            pass
        async with Session() as s:
            row=await s.get(Instance,iid)
            row.bot_token=token
            row.state="STOPPED"
            await s.commit()
        print(f"✅ Bot token changed and verified: @{me.username or me.first_name}")
        print("Controller is stopped. Start it again with option 5.")

    elif choice == "2":
        try:
            chat=_parse_chat_id(input("New Customer Chat ID: "))
        except ValueError as exc:
            print(f"❌ {exc}"); return
        async with Session() as s:
            row=await s.get(Instance,iid)
            row.customer_chat_id=chat
            await s.commit()
        print(f"✅ Customer Chat ID changed to {chat}")

    elif choice == "3":
        name=input("New instance name: ").strip()
        if not name or len(name)>80:
            print("❌ Name must be 1-80 characters."); return
        async with Session() as s:
            row=await s.get(Instance,iid)
            row.name=name
            await s.commit()
        print("✅ Instance name changed.")

    elif choice == "4":
        try:
            until, days, action=await _choose_validity(inst.validity_until)
        except (ValueError, EOFError) as exc:
            print(f"❌ {exc}"); return
        async with Session() as s:
            row=await s.get(Instance,iid)
            row.validity_until=until
            await s.commit()
        print(f"✅ Validity {action}.")
        print(f"Expires: {until.astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')}")

    elif choice in {"5","6"}:
        disabled=choice=="5"
        async with Session() as s:
            row=await s.get(Instance,iid)
            row.disabled=disabled
            if disabled:
                row.state="DISABLED"
            elif row.state=="DISABLED":
                row.state="STOPPED"
            await s.commit()
        print("✅ Instance disabled." if disabled else "✅ Instance enabled.")

    elif choice == "7":
        async with Session() as s:
            row=await s.get(Instance,iid)
            if not row:
                print("Not found."); return
            print(f"Name: {row.name}")
            print(f"Customer Chat ID: {row.customer_chat_id}")
            print(f"Bot token: {'configured' if row.bot_token else 'missing'}")
            print(f"State: {row.state}")
            print(f"Disabled: {row.disabled}")
            print(f"Validity until: {row.validity_until}")
            print(f"Logs: {row.log_chat_link or 'not ready'}")
    else:
        print("Unknown option.")


def live_tail(instance_id: int, interval: float = 1.0):
    """Follow one instance controller log until the operator presses B/Q."""
    import time as _time
    from app.process_manager import log_file, read_pid
    path = log_file(instance_id)
    print(f"\n========== LIVE LOGS — INSTANCE #{instance_id:02d} ==========")
    print(f"File: {path}")
    print("Press B or Q to go back to the instance menu.\n")
    last_size = 0
    try:
        if path.exists():
            last_size = path.stat().st_size
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            print("\n".join(lines[-30:]))
        while True:
            if path.exists():
                size = path.stat().st_size
                if size < last_size:
                    last_size = 0
                    print("\n--- log file rotated/truncated ---")
                if size > last_size:
                    with path.open("r", encoding="utf-8", errors="replace") as fh:
                        fh.seek(last_size)
                        chunk = fh.read()
                    last_size = size
                    if chunk:
                        print(chunk, end="" if chunk.endswith("\n") else "\n", flush=True)
            # Cross-platform non-blocking B/Q detection.
            if os.name == "nt":
                import msvcrt
                if msvcrt.kbhit():
                    key = msvcrt.getwch().lower()
                    if key in {"b", "q"}:
                        print("\nReturning to instance menu...")
                        return
            else:
                import select as _select, sys as _sys
                ready, _, _ = _select.select([_sys.stdin], [], [], 0)
                if ready:
                    key = _sys.stdin.readline().strip().lower()
                    if key in {"b", "q", ""}:
                        print("\nReturning to instance menu...")
                        return
            if not read_pid(instance_id) and path.exists():
                print("\n⚠️ Controller is not running. Showing remaining log; press B/Q to go back.")
            _time.sleep(interval)
    except KeyboardInterrupt:
        print("\nReturning to instance menu...")


async def interactive():
    await init_db()
    while True:
        print("\n========== ADSGENIE ==========")
        print("1. Create instance")
        print("2. List instances")
        print("3. Login MTProto account")
        print("4. Sync already-joined chats (no auto-join)")
        print("5. Start controller (background)")
        print("6. Set campaign")
        print("7. Stop controller")
        print("8. Controller status")
        print("9. Controller logs")
        print("10. Show instance status")
        print("11. Create/Repair Logs channel")
        print("12. Edit instance / token / Chat ID / validity")
        print("13. View LIVE logs (press B/Q to go back)")
        print("14. Filter destinations + update persistent blacklist")
        print("0. Exit")
        c=input("Select: ").strip()
        if c=="1":
            await create_instance()
        elif c=="2":
            await list_instances()
        elif c=="12":
            await edit_instance()
        elif c=="13":
            try:
                iid=int(input("Instance ID: ").strip())
            except ValueError:
                print("Invalid instance ID.")
                continue
            live_tail(iid)
        elif c == "14":
            try:
                iid=int(input("Instance ID: ").strip())
            except ValueError:
                print("Invalid instance ID."); continue
            from app.services.destination_filter import filter_instance_destinations, blacklist_path, load_blacklist
            result = await filter_instance_destinations(iid)
            print("\n========== DESTINATION FILTER ==========")
            print(f"Result: {result.get('reason', 'COMPLETE')}")
            print(f"Checked now: {result.get('checked', 0)}")
            print(f"New blacklist entries: {result.get('blacklisted', 0)}")
            print(f"Skipped from saved blacklist: {result.get('skipped_cached', 0)}")
            print(f"Saved file: {blacklist_path(iid)}")
        elif c in {"3","4","5","6","7","8","9","10","11"}:
            try:
                iid=int(input("Instance ID: ").strip())
            except ValueError:
                print("Invalid instance ID.")
                continue
            if c=="3":
                from app.mtproto.auth import login_instance
                await login_instance(iid)
            elif c=="4":
                from app.mtproto.addlists import sync_addlists
                await sync_addlists(iid)
            elif c=="5":
                from app.process_manager import start
                start(iid)
            elif c=="6":
                link=input("Telegram channel post link (https://t.me/channel/123): ").strip()
                if not link.startswith(("https://t.me/","http://t.me/")):
                    print("Invalid Telegram post link."); continue
                async with Session() as s:
                    result=await s.execute(select(Campaign).where(Campaign.instance_id==iid).order_by(Campaign.id.desc()).limit(1))
                    campaign=result.scalar_one_or_none()
                    if campaign:
                        campaign.text=link; campaign.source_link=link; campaign.active=False; campaign.updated_at=datetime.now(timezone.utc)
                    else:
                        s.add(Campaign(instance_id=iid,text=link,source_link=link,active=False,updated_at=datetime.now(timezone.utc)))
                    await s.commit()
                print("Campaign post saved. It can also be changed from the controller with /change.")
            elif c=="7":
                from app.process_manager import stop
                stop(iid)
            elif c=="8":
                from app.process_manager import status
                status(iid)
            elif c=="9":
                from app.process_manager import tail
                tail(iid)
            elif c=="10":
                async with Session() as s:
                    x=await s.get(Instance,iid)
                    print(x.__dict__ if x else "Not found")
            elif c=="11":
                from app.bots.controller import repair_logs_channel
                try:
                    result = await repair_logs_channel(iid)
                    print("\n✅ Logs channel READY")
                    print(f"   Title: {result['title']}")
                    print(f"   Chat ID: {result['chat_id']}")
                    print(f"   Link: {result['link'] or 'No invite link returned'}")
                except Exception as exc:
                    print(f"\n❌ Logs channel repair failed: {type(exc).__name__}: {exc}")
        elif c=="0":
            return
        else:
            print("Unknown option.")
