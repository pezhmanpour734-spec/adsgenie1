from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

PROJECT_ROOT = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    environment: str = "development"
    database_url: str = f"sqlite+aiosqlite:///{(PROJECT_ROOT / 'data' / 'adsgenie.db').as_posix()}"
    max_instances: int = 40
    admin_chat_id: int = 0
    monitor_channel_id: int = 0
    api_id: int = 0
    api_hash: str = ""
    batch_size: int = 25
    min_delay_seconds: int = 60
    batch_cooldown_seconds: int = 3600
    session_dir: str = str(PROJECT_ROOT / "sessions")
    log_dir: str = str(PROJECT_ROOT / "logs")
    instance_id: int = 1
    addlist_1: str = ""
    addlist_2: str = ""

    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / ".env",
        extra="ignore",
    )

    def __init__(self, **values):
        super().__init__(**values)
        # Convert relative filesystem paths to stable project-root paths.
        if not Path(self.session_dir).is_absolute():
            self.session_dir = str(PROJECT_ROOT / self.session_dir)
        if not Path(self.log_dir).is_absolute():
            self.log_dir = str(PROJECT_ROOT / self.log_dir)

        # A relative SQLite URL must always point to the project DB, even when
        # a child process is started with a different current working directory.
        if self.database_url.startswith("sqlite+aiosqlite:///"):
            raw = self.database_url[len("sqlite+aiosqlite:///"):]
            raw_path = Path(raw)
            if not raw_path.is_absolute():
                self.database_url = (
                    "sqlite+aiosqlite:///"
                    + (PROJECT_ROOT / raw_path).resolve().as_posix()
                )

        Path(self.session_dir).mkdir(parents=True, exist_ok=True)
        Path(self.log_dir).mkdir(parents=True, exist_ok=True)
        (PROJECT_ROOT / "data").mkdir(parents=True, exist_ok=True)

    def required_ok(self):
        return bool(self.admin_chat_id and self.api_id and self.api_hash)


settings = Settings()
