from pathlib import Path
from telethon import TelegramClient
from sqlalchemy import select
from app.config import settings
from app.db import Session, Account

async def login_instance(instance_id:int):
    async with Session() as s:
        acc=(await s.execute(select(Account).where(Account.instance_id==instance_id))).scalar_one_or_none()
        if not acc:
            print("Account record not found. Create the instance first."); return
        session=Path(acc.session_path)
    session.parent.mkdir(parents=True,exist_ok=True)
    client=TelegramClient(str(session), settings.api_id, settings.api_hash)
    phone=input("Phone number for THIS account (initial authentication only): ").strip()
    await client.start(phone=phone)
    me=await client.get_me()
    async with Session() as s:
        acc=(await s.execute(select(Account).where(Account.instance_id==instance_id))).scalar_one()
        acc.telegram_user_id=me.id
        acc.phone_hint=phone[-4:] if len(phone)>=4 else ""
        acc.first_name=me.first_name or ""
        acc.username=me.username or ""
        acc.authenticated=True
        await s.commit()
    print(f"Authenticated instance #{instance_id}: @{me.username or 'no_username'}")
    await client.disconnect()

    # Import configured addlists after authentication. No background/live target
    # filtering is performed here; the forwarding engine handles delivery errors.
    try:
        from app.mtproto.addlists import sync_addlists
        await sync_addlists(instance_id)
    except Exception as exc:
        print(f"⚠️ Addlist sync failed: {type(exc).__name__}: {exc}")


async def replace_instance_account(instance_id: int):
    """Explicit replacement entry point for a legitimate new MTProto account."""
    return await login_instance(instance_id)
