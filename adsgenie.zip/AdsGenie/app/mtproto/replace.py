import inspect
from app.mtproto import auth


async def replace_account(instance_id: int):
    fn = getattr(auth, "replace_instance_account", None)
    if fn is None:
        fn = getattr(auth, "login_instance", None)
    if fn is None:
        raise RuntimeError("MTProto login function is not available in this build.")
    result = fn(instance_id)
    if inspect.isawaitable(result):
        return await result
    return result
