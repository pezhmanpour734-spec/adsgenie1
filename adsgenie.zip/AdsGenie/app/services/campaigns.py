import re
import asyncio
import time
import hashlib
from html import escape
from datetime import datetime, timezone

from sqlalchemy import select
from telethon import TelegramClient, errors, functions

from app.config import settings
from app.db import Session, Instance, Account, Campaign, Destination
from app.mtproto.session_lock import session_lock
from app.services.destination_filter import add_blacklist, load_blacklist


# Per-process delivery-cycle deduplication, adapted from the supplied forwarding logic.
# It is reset after each complete campaign cycle and never overrides authorization checks.
_cycle_seen: dict[int, set[tuple[int, str]]] = {}


def parse_post_link(link: str):
    link = (link or "").strip()
    m = re.fullmatch(r"https?://t\.me/(?:c/(\d+)|([A-Za-z0-9_]{4,}))/([0-9]+)(?:\?[^\s]+)?", link, re.I)
    if not m:
        return None
    return {"chat": int(f"-100{m.group(1)}") if m.group(1) else m.group(2), "message_id": int(m.group(3))}


def destination_category(entity) -> str:
    from telethon.tl.types import Channel, Chat
    if isinstance(entity, Channel):
        if getattr(entity, "forum", False):
            return "FORUMS"
        if getattr(entity, "broadcast", False):
            return "CHANNELS"
        return "GROUPS"
    if isinstance(entity, Chat):
        return "GROUPS"
    return "OTHER"


async def load_campaign(instance_id: int):
    async with Session() as s:
        result = await s.execute(
            select(Campaign).where(Campaign.instance_id == instance_id).order_by(Campaign.id.desc()).limit(1)
        )
        return result.scalar_one_or_none()


async def set_campaign_active(instance_id: int, active: bool):
    async with Session() as s:
        result = await s.execute(
            select(Campaign).where(Campaign.instance_id == instance_id).order_by(Campaign.id.desc()).limit(1)
        )
        c = result.scalar_one_or_none()
        if c:
            c.active = active
            c.updated_at = datetime.now(timezone.utc)
        inst = await s.get(Instance, instance_id)
        if inst:
            inst.state = "RUNNING" if active else "STOPPED"
        await s.commit()
        return c


async def set_target_category(instance_id: int, category: str):
    category = category.upper()
    if category not in {"ALL", "GROUPS", "FORUMS", "CHANNELS"}:
        category = "ALL"
    async with Session() as s:
        result = await s.execute(
            select(Campaign).where(Campaign.instance_id == instance_id).order_by(Campaign.id.desc()).limit(1)
        )
        c = result.scalar_one_or_none()
        if not c:
            c = Campaign(instance_id=instance_id, text="", source_link="", active=False)
            s.add(c)
            await s.flush()
        c.target_category = category
        c.updated_at = datetime.now(timezone.utc)
        await s.commit()
        return c


async def destination_counts(instance_id: int):
    async with Session() as s:
        rows = (await s.execute(select(Destination).where(Destination.instance_id == instance_id))).scalars().all()
    counts = {"ALL": 0, "GROUPS": 0, "FORUMS": 0, "CHANNELS": 0}
    for d in rows:
        if not (d.authorized and d.enabled):
            continue
        counts["ALL"] += 1
        key = (d.category or "OTHER").upper()
        if key in counts:
            counts[key] += 1
    return counts


async def _sent_message_link(client, target, sent_message, destination) -> str | None:
    """Return a clickable link to the exact message just delivered."""
    msg_id = getattr(sent_message, "id", None)
    if not msg_id:
        return None

    # Telethon can export a proper message link for channels/supergroups,
    # including private chats where a public username is unavailable.
    try:
        from telethon import functions
        entity = await client.get_entity(target)
        if getattr(entity, "broadcast", False) or getattr(entity, "megagroup", False):
            exported = await client(functions.channels.ExportMessageLinkRequest(
                channel=entity,
                id=int(msg_id),
                grouped=False,
                thread=False,
            ))
            link = getattr(exported, "link", None)
            if link:
                return link
    except Exception:
        pass

    username = getattr(destination, "username", None)
    if username:
        return f"https://t.me/{username}/{int(msg_id)}"

    # Fallback for Telegram channel/supergroup IDs stored in Bot-API format.
    try:
        chat_id = int(destination.chat_id)
        if chat_id <= -1000000000000:
            internal_id = abs(chat_id) - 1000000000000
            return f"https://t.me/c/{internal_id}/{int(msg_id)}"
    except Exception:
        pass
    return None


async def _open_forum_topic(client, target):
    """Resolve a usable open forum topic, preferring General (source-style).

    This imports the useful forum-routing behavior from the supplied forwarding
    implementation while deliberately avoiding its self-forward probing.
    """
    try:
        topics = await client(functions.messages.GetForumTopicsRequest(
            peer=target, q="", offset_date=0, offset_id=0, offset_topic=0, limit=100
        ))
        items = list(getattr(topics, "topics", []) or [])
        open_topics = [
            t for t in items
            if not bool(getattr(t, "closed", False))
            and not bool(getattr(t, "hidden", False))
            and getattr(t, "id", None) is not None
        ]
        if not open_topics:
            return None
        general = next((t for t in open_topics if int(getattr(t, "id", 0)) == 1), None)
        return int(getattr(general or open_topics[0], "id"))
    except Exception:
        return None


def _message_hash(message) -> str:
    """Source-style message fingerprint used for per-cycle duplicate protection."""
    base = getattr(message, "message", None) or ""
    media = getattr(message, "media", None)
    if media is not None:
        base += repr(media)
    return hashlib.sha256(base.encode("utf-8")).hexdigest()


def _message_from_forward_updates(result):
    messages = []
    for update in list(getattr(result, "updates", []) or []):
        msg = getattr(update, "message", None)
        if msg is not None and getattr(msg, "id", None):
            messages.append(msg)
    return max(messages, key=lambda m: int(getattr(m, "id", 0))) if messages else None


async def _forward_one(client, source, source_chat, target, entity):
    """Forward exactly one configured post using the supplied file's core logic.

    Normal Groups use Telethon's native forward API. Forums are routed into an
    existing open topic. No auto-join, random delay, anti-detection behavior,
    or unsolicited-destination behavior is imported.
    """
    if getattr(entity, "megagroup", False) and getattr(entity, "forum", False):
        topic_id = await _open_forum_topic(client, target)
        if topic_id is None:
            raise RuntimeError("NO_OPEN_FORUM_TOPIC")
        result = await client(functions.messages.ForwardMessagesRequest(
            from_peer=source_chat,
            id=[int(source.id)],
            to_peer=target,
            top_msg_id=topic_id,
        ))
        sent = _message_from_forward_updates(result)
        if sent is None:
            recent = await client.get_messages(target, limit=5)
            sent = recent[0] if recent else None
        if sent is None:
            raise RuntimeError("FORWARD_RESULT_MESSAGE_NOT_FOUND")
        return sent, topic_id

    result = await client.forward_messages(target, source, from_peer=source_chat)
    sent = result[0] if isinstance(result, (list, tuple)) else result
    return sent, None


async def run_campaign_once(instance_id: int, bot, logger, category: str | None = None):
    """Run one delivery cycle while exclusively owning the Telethon session file."""
    async with Session() as s:
        acc = (await s.execute(select(Account).where(Account.instance_id == instance_id))).scalar_one_or_none()
    if not acc or not acc.authenticated:
        return {"ok": False, "reason": "NO_ACCOUNT", "sent": 0, "failed": 0, "total": 0}
    async with session_lock(acc.session_path):
        return await _run_campaign_once_unlocked(instance_id, bot, logger, category)


async def _run_campaign_once_unlocked(instance_id: int, bot, logger, category: str | None = None):
    """Forward the configured source post once to authorized destinations.

    The pacing is strictly per destination: after every attempted delivery we
    establish the next eligible send time from a monotonic clock. Batch cooldown
    is applied only after a complete configured batch. This prevents the first
    message of a cycle from being followed by an accidental multi-minute wait.
    """
    campaign = await load_campaign(instance_id)
    if not campaign or not campaign.source_link:
        return {"ok": False, "reason": "NO_CAMPAIGN", "sent": 0, "failed": 0, "total": 0}

    parsed = parse_post_link(campaign.source_link)
    if not parsed:
        return {"ok": False, "reason": "INVALID_SOURCE", "sent": 0, "failed": 0, "total": 0}

    selected = (category or getattr(campaign, "target_category", "ALL") or "ALL").upper()
    if selected not in {"ALL", "GROUPS_FORUMS", "GROUPS", "FORUMS"}:
        selected = "GROUPS_FORUMS"

    async with Session() as s:
        acc = (await s.execute(select(Account).where(Account.instance_id == instance_id))).scalar_one_or_none()
        q = select(Destination).where(
            Destination.instance_id == instance_id,
            Destination.authorized.is_(True),
            Destination.enabled.is_(True),
        )
        if selected == "GROUPS_FORUMS":
            q = q.where(Destination.category.in_(["GROUPS", "FORUMS"]))
        elif selected != "ALL":
            q = q.where(Destination.category == selected)
        destinations = (await s.execute(q.order_by(Destination.id))).scalars().all()
    # Persisted definitive skips are not reconsidered during each campaign cycle.
    blacklisted_ids = load_blacklist(instance_id)
    destinations = [d for d in destinations if d.chat_id is not None and str(d.chat_id) not in blacklisted_ids]

    if not acc or not acc.authenticated:
        return {"ok": False, "reason": "NO_ACCOUNT", "sent": 0, "failed": 0, "total": len(destinations)}
    if not destinations:
        return {"ok": False, "reason": "NO_TARGETS", "sent": 0, "failed": 0, "total": 0}

    async def safe_logger(message_text: str, view_link: str | None = None):
        # Logging must NEVER terminate delivery. A Bot API logging error,
        # including a log-channel rate limit, is isolated from the MTProto
        # forwarding loop.
        try:
            await logger(message_text, view_link)
        except Exception as log_exc:
            # Keep this deliberately lightweight: do not make another Telegram
            # request from inside the error handler.
            print(f"Instance #{instance_id:02d}: log delivery failed: {type(log_exc).__name__}: {log_exc}")

    client = TelegramClient(acc.session_path, settings.api_id, settings.api_hash)
    await client.connect()
    sent_count = failed_count = 0
    next_send_at = time.monotonic()
    cycle_seen = _cycle_seen.setdefault(instance_id, set())
    cycle_seen.clear()
    try:
        if not await client.is_user_authorized():
            return {"ok": False, "reason": "ACCOUNT_UNAUTHORIZED", "sent": 0, "failed": 0, "total": len(destinations)}
        source = await client.get_messages(parsed["chat"], ids=parsed["message_id"])
        if not source:
            return {"ok": False, "reason": "SOURCE_NOT_FOUND", "sent": 0, "failed": 0, "total": len(destinations)}

        for index, d in enumerate(destinations, start=1):
            async with Session() as s:
                fresh = await s.get(Instance, instance_id)
            if not fresh or fresh.state != "RUNNING":
                break

            # Strict one-message-at-a-time pacing. This deadline is based on the
            # actual previous attempt, not on batch/cycle bookkeeping.
            wait_for = next_send_at - time.monotonic()
            if wait_for > 0:
                await asyncio.sleep(wait_for)

            try:
                target = await client.get_input_entity(d.chat_id)
                # Normal groups do not need a second entity lookup. Forums do,
                # because topic routing needs the forum/channel entity.
                entity = await client.get_entity(target) if (d.category or '').upper() == 'FORUMS' else None

                message_key = (int(d.chat_id), _message_hash(source))
                if message_key in cycle_seen:
                    await safe_logger(
                        f"↩️ <b>DUPLICATE SKIPPED</b>\n"
                        f"Instance: #{instance_id:02d}\n"
                        f"Target: <b>{escape(d.title or d.username or str(d.chat_id))}</b>"
                    )
                    continue

                sent, topic_id = await _forward_one(client, source, parsed["chat"], target, entity)
                cycle_seen.add(message_key)
                sent_count += 1
                msg_id = getattr(sent, "id", None)
                view_link = await _sent_message_link(client, target, sent, d)
                await safe_logger(
                    f"╭━━━ <b>ADSGENIE • DELIVERY</b> ━━━╮\n"
                    f"\n🟢 <b>SUCCESSFULLY FORWARDED</b>\n"
                    f"\n📍 <b>Destination</b>\n└ {escape(str(d.title or d.username or d.chat_id))}\n"
                    f"🗂 <b>Type</b> · <code>{escape(str(d.category or '-'))}</code>\n"
                    f"🧵 <b>Forum topic</b> · <code>{escape(str(topic_id or 'General / N/A'))}</code>\n"
                    f"🆔 <b>Message ID</b> · <code>{escape(str(msg_id or '-'))}</code>\n"
                    f"🔗 <b>Source</b> · <code>{escape(str(campaign.source_link))}</code>\n"
                    f"╰━━━━━━━━━━━━━━━━━━━━╯",
                    view_link,
                )
            except errors.FloodWaitError as exc:
                # FloodWait is a per-request Telegram rate limit, not a fatal
                # campaign error. Respect the exact server-provided delay, then
                # continue with the next destination. Logging is isolated so a
                # log-channel error cannot stop this loop.
                failed_count += 1
                wait_seconds = max(1, int(getattr(exc, 'seconds', 1)))
                await safe_logger(
                    f"⏳ <b>FLOOD WAIT — DELIVERY PAUSED</b>\n"
                    f"Instance: #{instance_id:02d}\n"
                    f"Target: <b>{escape(d.title or d.username or str(d.chat_id))}</b>\n"
                    f"Telegram requested: <code>{wait_seconds}s</code>\n"
                    f"Action: <b>wait, then continue queue</b>"
                )
                await asyncio.sleep(wait_seconds)
                await safe_logger(
                    f"▶️ <b>QUEUE RESUMED</b>\n"
                    f"Instance: #{instance_id:02d}\n"
                    f"Next: <b>{escape(d.title or d.username or str(d.chat_id))}</b>\n"
                    f"Progress: <code>{index}/{len(destinations)}</code>"
                )
            except Exception as exc:
                error_name = type(exc).__name__
                error_text = str(exc)
                if "ChatWriteForbidden" in error_name or "CHAT_WRITE_FORBIDDEN" in error_text or "ChatAdminRequired" in error_name or "CHAT_ADMIN_REQUIRED" in error_text:
                    failed_count += 1
                    add_blacklist(instance_id, d.chat_id, "NO_POST_PERMISSION", d.title or d.username)
                    async with Session() as db:
                        row = await db.get(Destination, d.id)
                        if row:
                            row.authorized = False
                            row.can_post = False
                            row.enabled = False
                            row.last_checked_at = datetime.now(timezone.utc)
                            await db.commit()
                    await safe_logger(
                        f"⚪ <b>TARGET SKIPPED</b>\n"
                        f"Instance: #{instance_id:02d}\n"
                        f"Target: <b>{escape(str(d.title or d.username or d.chat_id))}</b>\n"
                        f"Reason: <code>CHAT_WRITE_FORBIDDEN</code>\n"
                        f"Posting permission is no longer available."
                    )
                elif "ALLOW_PAYMENT_REQUIRED" in error_text or "PaymentRequired" in error_name or "BALANCE_TOO_LOW" in error_name or "BALANCE_TOO_LOW" in error_text:
                    failed_count += 1
                    add_blacklist(instance_id, d.chat_id, "PAID_MESSAGES_STARS", d.title or d.username)
                    async with Session() as db:
                        row = await db.get(Destination, d.id)
                        if row:
                            row.authorized = False
                            row.can_post = False
                            row.enabled = False
                            row.last_checked_at = datetime.now(timezone.utc)
                            await db.commit()
                    await safe_logger(
                        f"💎 <b>PAID DESTINATION SKIPPED</b>\n"
                        f"Instance: <code>#{instance_id:02d}</code>\n"
                        f"Destination: <b>{escape(str(d.title or d.username or d.chat_id))}</b>\n"
                        f"Reason: <code>TELEGRAM_STARS_REQUIRED</code>\n"
                        f"Saved to the instance blacklist; no Stars were spent."
                    )
                elif "TopicClosed" in error_name or "TOPIC_CLOSED" in error_text or "NO_OPEN_FORUM_TOPIC" in error_text:
                    failed_count += 1
                    await safe_logger(
                        f"⚪ <b>FORUM TARGET SKIPPED</b>\n"
                        f"Instance: #{instance_id:02d}\n"
                        f"Target: <b>{escape(str(d.title or d.username or d.chat_id))}</b>\n"
                        f"Reason: <code>NO_OPEN_FORUM_TOPIC</code>\n"
                        f"No open topic is available right now."
                    )
                else:
                    failed_count += 1
                    await safe_logger(
                        f"❌ <b>AD FAILED</b>\n"
                        f"Instance: #{instance_id:02d}\n"
                        f"Target: <b>{escape(str(d.title or d.username or d.chat_id))}</b>\n"
                        f"Error: <code>{escape(error_name + ": " + error_text[:500])}</code>"
                    )
            finally:
                # The one-minute interval starts after the attempt finishes.
                # This guarantees a slow Telegram request cannot make the next
                # delivery arrive earlier than the configured interval.
                next_send_at = time.monotonic() + max(0, settings.min_delay_seconds)

            if index < len(destinations) and index % settings.batch_size == 0:
                await safe_logger(
                    f"🕐 <b>BATCH COOLDOWN</b>\nInstance: #{instance_id:02d}\n"
                    f"Processed: <code>{index}</code>\n"
                    f"Sleeping: <code>{settings.batch_cooldown_seconds}s</code>"
                )
                await asyncio.sleep(settings.batch_cooldown_seconds)
                next_send_at = time.monotonic()
    finally:
        await client.disconnect()
        _cycle_seen.pop(instance_id, None)

    return {"ok": True, "reason": "DONE", "sent": sent_count, "failed": failed_count, "total": len(destinations)}

