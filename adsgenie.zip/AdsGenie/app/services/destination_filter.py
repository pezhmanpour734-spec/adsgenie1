"""Persistent destination eligibility filter for AdsGenie.

Only inspects destinations already present in the instance database. It never
joins chats, sends probe messages, pays Telegram Stars, or bypasses restrictions.
Definitive no-write and paid-message destinations are saved per instance so they
are not re-checked on every run.
"""
from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import select
from telethon import TelegramClient, functions
from telethon.tl.types import Channel, Chat

from app.config import PROJECT_ROOT, settings
from app.db import Account, Destination, Session
from app.mtproto.session_lock import session_lock


def blacklist_path(instance_id: int) -> Path:
    return PROJECT_ROOT / "runtime" / "blacklist" / f"instance_{int(instance_id):02d}.json"


def load_blacklist(instance_id: int) -> dict[str, dict[str, Any]]:
    path = blacklist_path(instance_id)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        items = payload.get("destinations", {}) if isinstance(payload, dict) else {}
        return items if isinstance(items, dict) else {}
    except (OSError, json.JSONDecodeError, TypeError):
        return {}


def is_blacklisted(instance_id: int, chat_id: int | str) -> bool:
    return str(chat_id) in load_blacklist(instance_id)


def add_blacklist(instance_id: int, chat_id: int | str, reason: str, title: str = "") -> None:
    """Atomically persist a definitive skip reason for one destination."""
    path = blacklist_path(instance_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    items = load_blacklist(instance_id)
    items[str(chat_id)] = {
        "reason": str(reason)[:120],
        "title": str(title)[:240],
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    temp = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    temp.write_text(json.dumps({"version": 1, "destinations": items}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(temp, path)


def _paid_stars(entity: Any, full: Any = None) -> int:
    """Return non-zero required Stars when Telegram exposes a paid-message flag."""
    values = [getattr(entity, "send_paid_messages_stars", 0)]
    if full is not None:
        values.append(getattr(full, "send_paid_messages_stars", 0))
        peer = getattr(full, "full_chat", None)
        if peer is not None:
            values.append(getattr(peer, "send_paid_messages_stars", 0))
    for value in values:
        try:
            if value is not None and int(value) > 0:
                return int(value)
        except (TypeError, ValueError):
            continue
    return 0


async def _check_destination(client: TelegramClient, chat_id: int) -> tuple[str | None, str]:
    """Return (blacklist_reason, detail); None reason means eligible/unknown."""
    entity = await client.get_entity(chat_id)
    full = None
    if isinstance(entity, Channel):
        try:
            full = await client(functions.channels.GetFullChannelRequest(channel=entity))
        except Exception:
            # A cached entity flag is still useful; failure to fetch full info is
            # not itself grounds for blacklisting.
            full = None
    stars = _paid_stars(entity, full)
    if stars > 0:
        return "PAID_MESSAGES_STARS", f"requires {stars} Telegram Stars per message"

    permissions = await client.get_permissions(entity, "me")
    if isinstance(entity, Channel) and getattr(entity, "broadcast", False):
        can_post = bool(getattr(permissions, "post_messages", False))
    else:
        can_post = bool(getattr(permissions, "send_messages", True))
    if not can_post:
        return "NO_POST_PERMISSION", "account does not have posting permission"
    return None, "eligible"


async def filter_instance_destinations(instance_id: int) -> dict[str, int | str]:
    """Check cached destinations once and persist definitive ineligible targets."""
    async with Session() as db:
        account = (await db.execute(select(Account).where(Account.instance_id == instance_id))).scalar_one_or_none()
        destinations = (await db.execute(
            select(Destination).where(Destination.instance_id == instance_id).order_by(Destination.id)
        )).scalars().all()
    if not account or not account.authenticated:
        return {"ok": False, "reason": "ACCOUNT_NOT_AUTHENTICATED", "checked": 0, "blacklisted": 0, "skipped_cached": 0}

    cached = load_blacklist(instance_id)
    pending = [d for d in destinations if str(d.chat_id) not in cached and d.chat_id is not None]
    skipped_cached = len(destinations) - len(pending)
    checked = blacklisted = 0
    client = TelegramClient(account.session_path, settings.api_id, settings.api_hash)
    async with session_lock(account.session_path):
        await client.connect()
        try:
            if not await client.is_user_authorized():
                return {"ok": False, "reason": "SESSION_UNAUTHORIZED", "checked": 0, "blacklisted": 0, "skipped_cached": skipped_cached}
            for destination in pending:
                try:
                    reason, detail = await _check_destination(client, int(destination.chat_id))
                    checked += 1
                    if reason:
                        add_blacklist(instance_id, destination.chat_id, reason, destination.title)
                        blacklisted += 1
                        async with Session() as db:
                            row = await db.get(Destination, destination.id)
                            if row:
                                row.authorized = False
                                row.can_post = False
                                row.enabled = False
                                row.last_checked_at = datetime.now(timezone.utc)
                                await db.commit()
                        print(f"AdsGenie #{instance_id:02d}: blacklisted {destination.title or destination.chat_id}: {reason} ({detail})")
                    else:
                        async with Session() as db:
                            row = await db.get(Destination, destination.id)
                            if row:
                                row.authorized = True
                                row.can_post = True
                                row.enabled = True
                                row.last_checked_at = datetime.now(timezone.utc)
                                await db.commit()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    # Transient/network/unknown errors are NOT cached as permanent.
                    print(f"AdsGenie #{instance_id:02d}: filter deferred {destination.title or destination.chat_id}: {type(exc).__name__}")
        finally:
            await client.disconnect()
    return {"ok": True, "checked": checked, "blacklisted": blacklisted, "skipped_cached": skipped_cached, "total": len(destinations)}
