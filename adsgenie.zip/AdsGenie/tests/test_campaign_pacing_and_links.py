from pathlib import Path


def test_campaign_has_strict_per_message_deadline():
    text = Path('app/services/campaigns.py').read_text()
    assert 'next_send_at = time.monotonic()' in text
    assert 'wait_for = next_send_at - time.monotonic()' in text
    assert 'next_send_at = time.monotonic() + max(0, settings.min_delay_seconds)' in text


def test_logs_have_view_message_button():
    text = Path('app/bots/controller.py').read_text()
    assert 'InlineKeyboardButton(text="👁 View Message", url=view_link)' in text
    assert 'reply_markup=markup' in text


def test_delivery_resolves_destination_message_link():
    text = Path('app/services/campaigns.py').read_text()
    assert 'ExportMessageLinkRequest' in text
    assert 'view_link = await _sent_message_link' in text


def test_supplied_forwarding_core_and_no_background_filter():
    campaigns = Path('app/services/campaigns.py').read_text()
    controller = Path('app/bots/controller.py').read_text()
    auth = Path('app/mtproto/auth.py').read_text()
    assert 'GetForumTopicsRequest' in campaigns
    assert 'ForwardMessagesRequest' in campaigns
    assert 'client.forward_messages' in campaigns
    assert 'NO_OPEN_FORUM_TOPIC' in campaigns
    assert 'destination_cache_loop' not in controller
    assert 'preflight_destinations' not in controller
    assert 'preflight_destinations' not in auth


def test_combined_start_and_log_rate_limit_isolated():
    controller = Path('app/bots/controller.py').read_text()
    campaigns = Path('app/services/campaigns.py').read_text()
    assert 'campaign_loop()' in controller
    assert 'category="GROUPS_FORUMS"' in controller
    assert 'target:GROUPS' not in controller
    assert 'target:FORUMS' not in controller
    assert 'TelegramRetryAfter' in controller
    assert 'delivery continues without waiting' in controller
    assert 'safe_logger' in campaigns

def test_capacity_and_sqlite_concurrency_defaults():
    config = Path('app/config.py').read_text()
    db = Path('app/db/__init__.py').read_text()
    assert 'max_instances: int = 40' in config
    assert 'journal_mode=WAL' in db
    assert 'busy_timeout=30000' in db
